#!/bin/bash
# find current location of this file
parent_path=$( cd "$(dirname "${BASH_SOURCE[0]}")" ; pwd -P )
# set this as work directory
cd "$parent_path"

# make a folder for each scenario analysis
mkdir -p ./lisem_runs/VFS_compare/

# copy base maps
cp -rf ./lisem_runs/res_base/soilloss.map ./lisem_runs/VFS_compare/soilloss_base.map
cp -rf ./lisem_runs/res_base/runoff.map ./lisem_runs/VFS_compare/runoff_base.map
cp -rf ./lisem_runs/res_base/pestlossDP.map ./lisem_runs/VFS_compare/pestlossDP_base.map
cp -rf ./lisem_runs/res_base/pestlossPP.map ./lisem_runs/VFS_compare/pestlossPP_base.map
cp -rf ./lisem_runs/maps/Base_maps/mask.map ./lisem_runs/VFS_compare/mask.map

# copy scenario maps
cp -rf ./lisem_runs/res_scenario/soilloss.map ./lisem_runs/VFS_compare/soilloss_scenario.map
cp -rf ./lisem_runs/res_scenario/runoff.map ./lisem_runs/VFS_compare/runoff_scenario.map
cp -rf ./lisem_runs/res_scenario/pestlossDP.map ./lisem_runs/VFS_compare/pestlossDP_scenario.map
cp -rf ./lisem_runs/res_scenario/pestlossPP.map ./lisem_runs/VFS_compare/pestlossPP_scenario.map

cp -rf ./lisem_runs/maps/VFS_maps/VFS.map ./lisem_runs/VFS_compare/VFS.map
# run pcraster script and make table
cd ./lisem_runs/VFS_compare/
../../programs/pcraster-4.1.0_x86-64/bin/pcrcalc.exe -f ../../pcr_scripts/VFS_analyse.mod
../../programs/pcraster-4.1.0_x86-64/bin/table.exe net_soil.map net_runoff.map net_PP.map net_DP.map spatial_sums.txt


#write text
cd "$parent_path"
sed -i '1,10s/^/Change in area of the VFS\nSediment (kg), Water (m3), PP (mg), DP (mg), area (m2)\n /' ./lisem_runs/VFS_compare/spatial_sums.txt


# clean up
rm ./lisem_runs/VFS_compare/net_soil.map
rm ./lisem_runs/VFS_compare/net_runoff.map
rm ./lisem_runs/VFS_compare/net_PP.map
rm ./lisem_runs/VFS_compare/net_DP.map
rm ./lisem_runs/VFS_compare/VFS.map
rm ./lisem_runs/VFS_compare/mask.map