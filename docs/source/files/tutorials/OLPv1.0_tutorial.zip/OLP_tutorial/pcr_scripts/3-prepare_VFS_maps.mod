#! --degrees --clone mask.map --lddin --matrixtable
#-------------------------------------------
# adjust maps to simulate VFS below potato fields

binding
	#maps we will update
	vfs = VFS.map;
	n = n.map;		# Manning's n
	ksat = ksat1.map;		# Saturated hydraulic conductivity (mm/h)
	per = per.map;		# fraction soil cover
	coh = coh.map;		# soil cohesion (kPa)
	
	# values for each parameter for a VFS
	vfs_n = 0.3;		# high Manning's n for grass
	vfs_ksat = 20;		# increase infiltration
	vfs_per = 1;		# soil is fully covered by grass
	vfs_coh = 7;		# grass has high root strength, flow detachment is low.


initial
# replace all values in the maps for the new vfs values
report  n = if(vfs eq 1, vfs_n, n);
report  ksat = if(vfs eq 1, vfs_ksat, ksat);
report  per = if(vfs eq 1, vfs_per, per);
report  coh = if(vfs eq 1, vfs_coh, coh);
