#! --degrees --clone mask.map --lddin --matrixtable
#-------------------------------------------
# compare Extreme Rain scenario with base run maps

binding
	#base maps
	soilloss_base = soilloss_base.map;
	runoff_base = runoff_base.map;
	DP_base = pestlossDP_base.map;
	PP_base = pestlossPP_base.map;

	#scenario maps
	soilloss_scenario = soilloss_scenario.map;
	runoff_scenario = runoff_scenario.map;
	DP_scenario = pestlossDP_scenario.map;
	PP_scenario = pestlossPP_scenario.map;

	# analysis maps
	soil_change = soilloss_change.map;
	runoff_change = runoff_change.map;
	DP_change = DP_change.map;
	PP_change = PP_change.map;

	net_soil = net_soil.map;
	net_runoff = net_runoff.map;
	net_PP = net_PP.map;
	net_DP = net_DP.map;


initial
# substract the maps from each other to see differences in redistribution

# negative values are increase deposition or less detachment
# positive values are increased detachment or less deposition

report	soil_change = soilloss_scenario - soilloss_base;
report	runoff_change = runoff_scenario - runoff_base;
report	DP_change = DP_scenario - DP_base;
report	PP_change = PP_scenario - PP_base;

# save summed maps for table
area = nominal(soilloss_base * 0 + 1);
# runoff in m3
runoff_m3 = runoff_change * celllength() * celllength() / 1000;
ddx = celllength() * celllength();

report	net_soil = areatotal(soil_change, area) * ddx;
report	net_runoff = areatotal(runoff_m3, area);
report	net_PP = areatotal(PP_change, area) * ddx;
report	net_DP = areatotal(DP_change, area) * ddx;